package com.java.generic;
class ObjectFactory{
	/**强调:静态方法中只能应用方法泛型*/
	static <T>T newInstance(Class<T> t) {
		return null;
	}
}
public class TestGeneric05 {

}
