package com.java.generic;
import java.util.ArrayList;
import java.util.List;
public class TestGeneric07 {
	//指定泛型的上届<? extends 类型>
    static void sort(List<? extends Object> list) {
    }
    //指定泛型下届<? super 类型>
    static void convert(List<? super String> list ) {
    }
	public static void main(String[] args) {
		List<String> list1=new ArrayList<String>();
		List<Integer> list2=new ArrayList<Integer>();
		List<Object> list3=new ArrayList<Object>();
		sort(list3);
		convert(list3);
	}
}
