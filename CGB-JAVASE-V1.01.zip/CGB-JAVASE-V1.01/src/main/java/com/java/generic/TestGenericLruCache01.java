package com.java.generic;
/**
 * 缓存对象:有界容器
 * 1)存储结构: hash+linkedlist
 * 2)算法:LRU(缓存淘汰算法)
 */
import java.util.LinkedHashMap;
class LruCache<K,V>{//泛型类
	private LinkedHashMap<K, V> lruCache;
	public LruCache(int maxCap) {
		lruCache=new LinkedHashMap<K,V>(
				maxCap,0.75f,true){//true表示记录访问顺序
			private static final long serialVersionUID = -6532560105750095867L;
			@Override
			protected boolean removeEldestEntry(java.util.Map.Entry<K, V> eldest) {
				return size()>maxCap;
			}//每次执行put方法都会调用此方法用来判定容器是否要移除元素
		};//匿名内部类(重写removeEldestEntry方法),定义规则
	}
	/**向缓存放数据*/
	public void put(K key,V value) {
		lruCache.put(key, value);
	}
	/**从缓存取数据*/
	public V get(K key) {
		return lruCache.get(key);
	}
	@Override
	public String toString() {
		return "LruCache " + lruCache + "";
	}
}
public class TestGenericLruCache01 {
    public static void main(String[] args) {
		LruCache<String,Integer> cache=
		new LruCache<>(3);
		cache.put("A", 100);
		cache.put("B", 200);
		cache.put("C", 300);
		cache.get("A");
		cache.put("D", 400);
		System.out.println(cache);//ABCD
	}
}