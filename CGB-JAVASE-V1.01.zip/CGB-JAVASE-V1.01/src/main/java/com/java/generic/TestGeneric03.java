package com.java.generic;
/**泛型类*/
class Container<T>{
	 public void add(T t) {}
	 public T get() {return null;}
}
class ContainerUtil{
	 /**泛型方法*/
	 public <T>T search(Class<T> t){return null;}
}
/**泛型接口*/
interface Task<Param,Result>{
	 Result execute(Param arg);
}
class ConvertTask implements Task<String,Integer>{
	@Override
	public Integer execute(String arg) {
		return Integer.valueOf(arg);
	}
}
public class TestGeneric03 {
    public static void main(String[] args) {
    	ConvertTask t1=new ConvertTask();
    	Integer t=t1.execute("100");
	}
}








