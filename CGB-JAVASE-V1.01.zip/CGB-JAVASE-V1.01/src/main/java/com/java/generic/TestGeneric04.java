package com.java.generic;

import java.util.ArrayList;
/**
 * 构建一个线程安全的arraylist集合,只要
 * 保证add和get方法的线程安全即可
*/
class SyncArrayList<E> extends ArrayList<E>{
	private static final long serialVersionUID = 5074566105576369576L;
	@Override
	public synchronized boolean add(E e) {
		  return super.add(e);
	}
	@Override
	public synchronized E get(int index) {
		return super.get(index);
	}
}
public class TestGeneric04 { 
	public static void main(String[] args) {
		SyncArrayList<String> list=
		new SyncArrayList<String>();
		list.add("ABCD");
	}
}



