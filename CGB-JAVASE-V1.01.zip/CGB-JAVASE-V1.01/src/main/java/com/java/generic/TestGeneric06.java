package com.java.generic;

public class TestGeneric06 {

	public static void main(String[] args)
	throws Exception{
		//"?"为泛型通配符
		Class<?> c1=Object.class;
		Class<Object> c2=Object.class;
		
		Class<?> c3=
		Class.forName("java.lang.Object");
	}
}
