package com.java.generic;
/**基于LinkedList构建一个栈容器
 * 1)存储结构:链表
 * 2)算法:先进后出
 * */
import java.util.LinkedList;
class Stack<T>{//泛型类
	private LinkedList<T> list=
	new LinkedList<>();
	/**入栈*/
	public void push(T t) {
		list.addFirst(t);
	}
	/**出栈*/
	public T pop() {
		return list.pop();
	}
}
public class TestGenericStack01 {
    public static void main(String[] args) {
		Stack<Integer> stack=new Stack<>();
	    stack.push(100);
	    stack.push(200);
	    stack.push(300);
	    System.out.println(stack.pop());
    }
}









