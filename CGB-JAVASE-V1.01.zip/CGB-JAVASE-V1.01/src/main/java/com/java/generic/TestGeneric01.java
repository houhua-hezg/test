package com.java.generic;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
/**演示泛型擦除*/
public class TestGeneric01 {
	
	public static void main(String[] args)
	throws Exception{
		//doExample01();
		doExample02();
	}
	private static void doExample02()throws Exception{
		HashMap<String,Integer> map=
		new HashMap<String, Integer>();
		map.put("A", 100);
		//map.put(1, true);
		//将1作为key,true作为value写入到map
		//1.获取类的字节码对象
		Class<?> c=map.getClass();
		//2.获取put方法
		Method method=
		c.getDeclaredMethod("put",
				Object.class,Object.class);
		//3.执行map对象的put方法
		method.invoke(map,1,new Boolean(true));
		System.out.println(map);
	}
	
	private static void doExample01() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
		ArrayList<String> list=
		new ArrayList<String>();
		list.add("A");
		list.add("B");
		//list.add(100);//编译时做不到
		//list.add(0, 100);//假如将100放到第0个位置
		//运行时可以借助反射技术将100存储到list集合
		//1.反射的起点?(入口)
		Class<?> c=list.getClass();
		//2.基于字节码对象获取add方法对象
		Method method=
		//c.getDeclaredMethod("add",Object.class);
		c.getDeclaredMethod("add",int.class,Object.class);
	    //3.执行方法对象
		//method.invoke(list,100);
		method.invoke(list,0,100);
		System.out.println(list);
	}
}




