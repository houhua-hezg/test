package com.java.generic;
import java.util.List;
/**泛型类定义*/
class PageObject<T>{
	private List<T> records;
}
/**泛型方法定义*/
class Session{
	public <T>T getInstance(Class<T> cls){
		return null;
	}
}
public class TestGeneric02 {
    public static void main(String[] args) {
		Session s1=new Session();
		Integer t1=s1.getInstance(Integer.class);
    }
}
