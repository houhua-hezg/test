package com.java.annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
/**
 * 说明
 * 1)@interface 用于定义注解
 * 2)@Target 用于描述注解可以修饰哪些成员
 * 3)@Retention 用于描述定义的注解何时有效
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface Entity{}//Entity.class
//==============================
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD,ElementType.METHOD})
@interface ID{}//ID.class
/**注解的应用*/
@Entity
class SysLog{
	@ID
	private int id;
}
public class TestAnnotation01 {
	public static void main(String[] args)
	throws Exception{
	  //1.判定SysLog类上是否有Entity注解
		Class<?> c1=SysLog.class;
		boolean flag = c1.isAnnotationPresent(Entity.class);
		System.out.println(flag);
	  //2.判定SysLog对象中id属性上是否有ID注解
		//2.1获取属性id
		Field f1 = c1.getDeclaredField("id");
		//2.2判定属性上是否有ID注解
		flag=f1.isAnnotationPresent(ID.class);
		System.out.println(flag);
	}
}







