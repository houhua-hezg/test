package com.java.annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Constructor;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
/**定义注解*/
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface Component{
	String value() default "";
}
@Component
class DefaultMailService{}
/*** 构建一个对象实例工厂
 *   1)通过工厂为指定类型创建对象
 *   2)将工厂创建的对象存起来*/
public class ObjectInstanceFactory {
	private Map<String,Object> objMap=
	new ConcurrentHashMap<>();
	
	private Object newInstance(Class<?> cls)
	throws Exception{
		Component component=
		cls.getDeclaredAnnotation(Component.class);
		if(component==null)return null;
		//1.获取类中的构造方法对象
		Constructor<?> con
		= cls.getDeclaredConstructor();
		//2.设置构造方法可访问
		if(!con.isAccessible())
		con.setAccessible(true);
		//3.基于构造方法对象创建类的实例对象
		Object obj=con.newInstance();
		String key=component.value();
		if(key==null||"".equals(key)) {
		  String clsName=cls.getSimpleName();
		  key=clsName.substring(0, 1).toLowerCase()+
		  clsName.substring(1);
		}
		objMap.put(key,obj);
		//System.out.println(objMap);
		return obj;
	}
	public <T>T getObject(String key,Class<T> cls)
	throws Exception{
		//????省略对key,class的校验环节
		//1.从对象池中获取对象,池中没有则创建
		Object obj=objMap.get(key);
		if(obj==null) {
			obj=newInstance(cls);
		}
		//2.返回对象
		return (T)obj;
	}
}