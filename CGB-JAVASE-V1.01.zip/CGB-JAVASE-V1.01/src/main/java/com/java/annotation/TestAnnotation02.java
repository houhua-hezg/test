package com.java.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface Service{
	/**注解中的属性定义*/
	String value() default "";
	boolean lazy() default true;
}
@Service(value="userService",lazy=false)
class DefaultSearchService{}

public class TestAnnotation02 {
	public static void main(String[] args) {
		//获取SysUserService上的@Service的注解信息
		//1.获取上类的@service注解
		Class<?> c=DefaultSearchService.class;
		Service service=
		c.getDeclaredAnnotation(Service.class);
		//2.获取@service注解上的属性值.
		String value = service.value();
		boolean lazy = service.lazy();
		System.out.println(value);
		System.out.println(lazy);
	}
}



