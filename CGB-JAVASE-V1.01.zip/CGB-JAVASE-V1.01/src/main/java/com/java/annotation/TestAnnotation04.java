package com.java.annotation;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;
/**构建一个用于创建对象的工厂对象*/
class ObjectFactory{
	private Map<String,Object> objMap=new HashMap<>();
	/**通过此方法创建指定类型的对象*/
	private Object newInstance(Class<?> cls)throws Exception {
	   //获取类上的Service注解
	   Service service=cls.getDeclaredAnnotation(Service.class);
	   if(service==null)return null;
	   //1.基于字节码对象获取类中构造方法对象
		Constructor<?> con = 
		cls.getDeclaredConstructor();
	   //2.设置构造方法可访问
		if(!con.isAccessible()) 
		con.setAccessible(true);
	   //3.基于构造方法对象构建类的实例对象.
		Object obj=con.newInstance();
		objMap.put(service.value(), obj);
		return obj;
	}
	/**通过此方法获取一个类的实例*/
	public <T>T getObject(String key,Class<T> cls)
	throws Exception{
	     //1.首先从map获取对象(相当于从池中取)
		 Object obj=objMap.get(key);
		 //2.map中没有则创建
		 if(obj==null) {
			 obj=newInstance(cls);
		 }
		 return (T)obj;
	}
}
public class TestAnnotation04 {
    public static void main(String[] args)
    throws Exception{
		//1.构建工厂对象
    	ObjectFactory of=new ObjectFactory();
    	//2.从工厂获取对象
    	DefaultSearchService userService1=
    	of.getObject("userService",DefaultSearchService.class);
	    System.out.println(userService1);
	    DefaultSearchService userService2=
	    of.getObject("userService",DefaultSearchService.class);
	    System.out.println(userService1==userService2);
    }
}








