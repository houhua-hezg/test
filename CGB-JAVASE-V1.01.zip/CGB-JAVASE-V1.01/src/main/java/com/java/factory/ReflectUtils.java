package com.java.factory;

import java.lang.reflect.Constructor;

public abstract class ReflectUtils {
	 /**创建类的实例对象*/
	 public static Object newInstance(Class<?> cls) {
	    try {
	    //1.获取构造方法对象
		Constructor<?> con=cls.getDeclaredConstructor();
	    //2.设置构造方法可访问
		if(!con.isAccessible())
	    con.setAccessible(true);
		//3.创建对象并返回
	    return con.newInstance();
	    }catch(Exception e) {
	    e.printStackTrace();
	    return null;
	    }
	 }
}
