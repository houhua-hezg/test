package com.java.factory;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.java.spring.BeanDefinition;

/**
 * 1.读配置文件 :BeanDefinitionReader
 * 2.封装配置信息:BeanDefinition,Map
 * 3.创建实例对象:ReflectUtil
 * 4.存储实例:Map<String,Object>
 * 5.提供查询实例的方式
 */
public class DefaultBeanFactory extends BeanDefinitionReader implements BeanFactory{

	public DefaultBeanFactory(String cfgFile) {
		super(cfgFile);
	}
	@Override
	public void registerBean(BeanDefinition bd) {
		System.out.println("beanMap="+beanMap);
		System.out.println("bd="+bd);
		beanMap.put(bd.getId(), bd);
	}
	/**获取类的实例对象*/
	public <T>T getObject(String key,Class<T> cls){
		 //0.对key和class进行校验
		 //1)校验key是否存在
		 if(!beanMap.containsKey(key))
		 throw new RuntimeException("no such key in bean map");
		 //2)校验类型对应的资源是否存在
		 BeanDefinition bd=beanMap.get(key);
		 if(!bd.getTargetClass().equals(cls.getName()))
		 throw new RuntimeException("no such bean class");
		 //1.从instanceMap中取
		 Object obj=instanceMap.get(key);
		 if(obj==null) {
			 obj=ReflectUtils.newInstance(cls);
			 instanceMap.put(key, obj);
		 }
		 //2.返回实例对象
		 return (T)obj;
	 }
	
     
	  
}







