package com.java.factory;

public interface BeanFactory {
	<T>T getObject(String key,Class<T> cls);
}
