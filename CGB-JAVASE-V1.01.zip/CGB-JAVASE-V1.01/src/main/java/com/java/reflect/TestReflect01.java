package com.java.reflect;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
class Point{
	private int x;
	private int y;
	public Point(int x,int y) {
		this.x=x;
		this.y=y;
	}
	@Override
	public String toString() {
		return "Point [x=" + x + ", y=" + y + "]";
	}
}
public class TestReflect01 {

	/**创建类的实例对象
	 * @param cls 要创建的实例对象对象的字节码类型
	 * @param paramTypes 对应的构造方法中参数类型
	 * @param args 执行构造方法时要传入的实际参数类型
	 * */
	static <T>T doCreateInstance(
			Class<T> cls,
			Class<?>[] paramTypes,
			Object[] args)throws Exception{
		Constructor<T> con=
		cls.getDeclaredConstructor(paramTypes);
		if(con.isAccessible())con.setAccessible(true);
		return con.newInstance(args);
	}
	public static void main(String[] args)throws Exception{
		//1.通过反射构建类的实例 
		Point p1=doCreateInstance(
				 Point.class,
				 new Class[] {int.class,int.class},
				 new Object[] {100,200});
		//2.通过反射为p1实例对象的x属性重新赋值为200
	    //2.1获取Point类的字节码对象
		Class<?> c=p1.getClass();
		//2.2基于字节码对象获取x属性
		Field fx = c.getDeclaredField("x");
		//2.3修改P1对象x属性的值
		fx.setAccessible(true);
		fx.set(p1, 200);
		System.out.println(p1);
	}
}