package com.java.serializable;
import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestSerializable03 {
	public static void main(String[] args) throws IOException {
		//构建对象
		JsonResult r=new JsonResult();
		r.setState(100);
		r.setMessage("update ok");
		//String s="{\"state\":100,\"message\":\"update ok\"}";
		//System.out.println(s);
		//将对象转换为json格式字符串(广义的序列化)
		ObjectMapper om=new ObjectMapper();
		String jsonResult=
		om.writeValueAsString(r);
		System.out.println(jsonResult);
		//将字符串转换为java对象(反序列化)
		JsonResult r2=
		om.readValue(jsonResult,JsonResult.class);
		System.out.println(r2);
	}
}



