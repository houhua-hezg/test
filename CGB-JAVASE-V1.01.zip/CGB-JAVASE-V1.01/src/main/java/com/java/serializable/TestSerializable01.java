package com.java.serializable;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class TestSerializable01 {
	static void serialize(Serializable value) {
		try {
		//2.1构建输出流对象ObjectOutputStream
		ObjectOutputStream oos = 
				new ObjectOutputStream(
						new FileOutputStream("f1.txt"));
		//2.2通过流对象将log写到文件
		oos.writeObject(value);
		//2.3释放资源
		oos.flush();
		oos.close();
		System.out.println("序列化ok");
		}catch(Exception e) {
		 e.printStackTrace();
		}
	}
	public static Serializable deserialize() {
		try {
		//1.构建IO对象
		ObjectInputStream in=new ObjectInputStream(
		new FileInputStream("f1.txt"));
		//2.反序列化数据
		Serializable obj=(Serializable)in.readObject();
		in.close();
		return obj;
		}catch(Exception e) {
		e.printStackTrace();
		return null;
		}
	}
	public static void main(String[] args) {
	   //1.构建一个对象
		SysLog log=new SysLog();
		log.setId(100);
		log.setUsername("tmooc");
	   //2.将日志对象序列化到文件
	    serialize(log);
	   //3.将对象从文件反序列化
		SysLog obj=(SysLog)deserialize();
		System.out.println(obj.getId());
		System.out.println(obj.getUsername());
	}
}
