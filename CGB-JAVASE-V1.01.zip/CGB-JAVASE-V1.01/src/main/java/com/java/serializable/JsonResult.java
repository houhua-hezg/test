package com.java.serializable;

import java.io.Serializable;

/**VO(Value Object):封装值*/
public class JsonResult implements Serializable{
	private static final long serialVersionUID = -7853845900060828709L;
	/**状态*/
	private int state;
	/**消息*/
	private String message;
	
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "JsonResult [state=" + state + ", message=" + message + "]";
	}


}
