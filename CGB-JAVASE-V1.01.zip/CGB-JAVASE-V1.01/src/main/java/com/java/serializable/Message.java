package com.java.serializable;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
/**
 * 通过此对象Externalizable实现自定义的序列化
 * 过程.
 */
public class Message implements Externalizable{
	private Integer id;//10
	private String title;
	private String content;
	private String createdTime;
	/**序列化时自动调用*/
	@Override
	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeUTF(title);
	}
	/**反序列化时自动调用*/
	@Override
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		title=in.readUTF();
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}
	@Override
	public String toString() {
		return "Message [id=" + id + ", title=" + title + ", content=" + content + ", createdTime=" + createdTime + "]";
	}
	
}
