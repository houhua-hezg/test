package com.java.serializable;

import com.alibaba.fastjson.JSON;

/**使用fastjson将对象转换为json格式字符串
 * 或将json格式字符串转换为java对象*/
public class TestSerializable04 {
    public static void main(String[] args) {
		//1.构建一个pojo对象
    	JsonResult r=new JsonResult();
    	r.setState(1);
    	r.setMessage("tedu");
    	//2.将如上对象转换为json格式字符串
    	String jsonStr=JSON.toJSONString(r);
    	System.out.println(jsonStr);
    	//3.将字符串转换为java对象
    	JsonResult obj=
    	JSON.parseObject(jsonStr,JsonResult.class);
	    System.out.println(obj);
    }
}





