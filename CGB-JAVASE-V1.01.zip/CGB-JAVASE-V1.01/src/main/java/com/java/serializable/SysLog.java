package com.java.serializable;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Base64;
import java.util.Date;

public class SysLog implements Serializable{
	private static final long serialVersionUID = -623582276388442418L;
	private transient Integer id;
	private String username;
	private Date createdTime;
	/**对象进行序列化时会默认调用writeObject
	 * 方法的编写必须要遵循如下规范:
	 * */
	private void writeObject(ObjectOutputStream out) throws IOException {
		//1.获取加密对象
		Base64.Encoder coder=Base64.getEncoder();
	    //2.加密数据
		byte[] array=
		coder.encode(username.getBytes());
		this.username=new String(array);
		//3.对对象进行默认序列化
		out.defaultWriteObject();
	}
	/**反序列化时会自动调用*/
	private void readObject(ObjectInputStream in) throws ClassNotFoundException, IOException {
		//1.反序列化
		in.defaultReadObject();
		//2.解密数据
		//2.1获取解密器对象
		Base64.Decoder decoder=Base64.getDecoder();
		//2.2执行解密操作
		byte[] array=
		decoder.decode(username.getBytes());
		//2.3为属性赋值
		this.username=new String(array);
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
}
