package com.java.serializable;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import com.caucho.hessian.io.Hessian2Input;
import com.caucho.hessian.io.Hessian2Output;

/**hessian 序列化框架的简易应用*/
public class TestSerializable05 {
	public static void main(String[] args)
	throws Exception{
		//1.构建一个对象
		JsonResult r=new JsonResult();
		r.setState(100);
		r.setMessage("update ok");
		//2.借助hessian将对象进行序列化
		Hessian2Output out = 
		new Hessian2Output(new FileOutputStream("test.xml"));
		out.writeObject(r);
		//out.flush();
		out.close();
		System.out.println("序列化OK");          
		//3.借助hessian将对象反序列化
		Hessian2Input in = 
		new Hessian2Input(new FileInputStream("test.xml"));
		JsonResult obj = (JsonResult)
		in.readObject(JsonResult.class);
		System.out.println(obj);
		in.close();
	}
}
