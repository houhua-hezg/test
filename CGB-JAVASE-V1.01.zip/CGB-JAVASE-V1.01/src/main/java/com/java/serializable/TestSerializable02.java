package com.java.serializable;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;

public class TestSerializable02 {

	public static void main(String[] args)
	throws Exception{
		//1.构建对象
		Message msg=new Message();
		msg.setId(100);
		msg.setTitle("CGB1902");
		msg.setContent("helloworld");
		msg.setCreatedTime("2019-04-23");
		//2.将对象序列化
		ObjectOutputStream out=
		new ObjectOutputStream(
		new FileOutputStream("f2"));
		out.writeObject(msg);
		out.close();
		//3.将对象反序列化
		ObjectInputStream in=
		new ObjectInputStream(
		new FileInputStream("f2"));
		Object obj=in.readObject();
		System.out.println(obj);
		in.close();
		
	}
}



