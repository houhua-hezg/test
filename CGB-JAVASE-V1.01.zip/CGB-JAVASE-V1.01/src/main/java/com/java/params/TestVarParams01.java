package com.java.params;

public class TestVarParams01 {

//	static void doMethod(int a) {}
//	static void doMethod(int a,int b) {}
//	static void doMethod(int a,int b,int c) {}
    //可变参数应用(特殊数组)
	static void doMethod(int...a) {
		System.out.println(a.length);
	}
	public static void main(String[] args) {
		doMethod(10);
		doMethod(10,20);
		doMethod(10,20,30);
		doMethod();
	}
}



