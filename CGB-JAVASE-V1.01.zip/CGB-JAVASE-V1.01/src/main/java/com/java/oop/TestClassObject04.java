package com.java.oop;
/**跟踪类的加载-XX:+TraceClassLoading */
class ClassA{
	static final int a=10;
	static {
		System.out.println("ClassA.static");
	}
}
class ClassB extends ClassA{
	static int b=20;
	static {
		System.out.println("ClassB.static");
	}
}
public class TestClassObject04 {
    public static void main(String[] args) 
    throws Exception{
		//doMethod01();
    	//doMethod02();
	}
    public static void doMethod02() {
    	//ClassB主动加载(ClassA,ClassB的静态代码块都会执行)
    	System.out.println(ClassB.b);
    	//ClassB为被动加载,ClassA为主动加载.(
    	//此时ClassA的静态代码块执行,ClassB不执行)
    	System.out.println(ClassB.a);
    }
    //alt+shift+m (快速将某段代码提取为一个方法)
	//通过如下方法验证static{}代码块在类加载时是否一定会执行.
    private static void doMethod01() throws ClassNotFoundException {
		//隐式加载
    	Class<?> c1=ClassA.class;//不执行static{}
    	ClassA obj1=new ClassA();//执行static{}
    	//显式加载
    	Class.forName("com.java.oop.ClassA");//执行static{}
    	ClassLoader loader=
    			ClassLoader.getSystemClassLoader();
    	Class.forName("com.java.oop.ClassA",
    			false,loader);//不执行静态代码块
    	loader.loadClass("com.java.oop.ClassA");//不会执行
	}
}
