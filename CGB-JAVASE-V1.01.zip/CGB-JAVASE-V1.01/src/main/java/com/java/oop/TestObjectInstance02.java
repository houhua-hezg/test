package com.java.oop;
class DefaultSearchService{
	public Object search(String key) {
		//System.out.println("start:"+System.currentTimeMillis());
		System.out.println("search by key ...");
		//System.out.println("end:"+System.currentTimeMillis());
		return "search result";
	}
}//OCP原则(对修改关闭,对扩展开放)
class LogSearchService extends DefaultSearchService{
	@Override
	public Object search(String key) {
		System.out.println("start:"+System.currentTimeMillis());
		Object result=super.search(key);
		System.out.println("end:"+System.currentTimeMillis());
		return result;
	}
}
public class TestObjectInstance02 {
    public static void main(String[] args) {
		DefaultSearchService s=
		//new DefaultSearchService();
		new LogSearchService();
		s.search("tmooc");
	}
}
