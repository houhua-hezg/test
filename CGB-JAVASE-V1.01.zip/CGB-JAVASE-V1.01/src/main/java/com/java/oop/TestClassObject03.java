package com.java.oop;
import java.util.HashMap;
import java.util.Map;
class ClassObject02{
	static Map<String,Object> map=new HashMap<String,Object>();
	static ClassObject02 instance=
			new ClassObject02();
	public ClassObject02() {
		map.put("key1", 100);
	} 
}
public class TestClassObject03 {
    public static void main(String[] args) throws Exception{
		//Class<?> c1=ClassObject02.class;
    	Class.forName("com.java.oop.ClassObject02");
	}
}
