package com.java.oop;

public class TestObjectInstance01 {
	public static void main(String[] args) {
		//在堆内存构建对象实例
		//此实例构建时需要在堆内存构建一块连续的内存空间
		Integer[] array=new Integer[10];
	}
}
