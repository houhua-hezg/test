package com.java.oop;
/**演示类加载时不一定会执行静态代码块*/
class ClassObject01{
	static {System.out.println("static{}");}
}
public class TestClassObject02 {
    public static void main(String[] args)
    		throws Exception {
		//Class<?> c1=ClassObject01.class;
		//Class<?> c2=Class.forName("com.java.oop.ClassObject01");
    	Class.forName("com.java.oop.ClassObject01",
				false,//initialize true
	    ClassLoader.getSystemClassLoader());//ClassLoader
	}
}
