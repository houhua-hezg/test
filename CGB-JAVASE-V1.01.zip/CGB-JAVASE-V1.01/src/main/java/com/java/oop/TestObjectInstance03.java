package com.java.oop;
interface MailService{
	void send(String content);
}
//如何在不修改此类的基础上实现一些拓展业务
final class DefaultMailService implements MailService{
	@Override
	public void send(String content) {
		System.out.println("send "+content);
	}
}//基于OCP原则进行扩展
class LogMailService implements MailService{
	//组合(has a)
	private MailService mailService;//DIP(依赖倒置:依赖于抽象而不是具体)
	public LogMailService(
		MailService mailService) {
		this.mailService=mailService;
	}
	@Override
	public void send(String content) {
		System.out.println("start:"+System.currentTimeMillis());
		mailService.send(content);
		System.out.println("end:"+System.currentTimeMillis());
	}
}
public class TestObjectInstance03 {
    public static void main(String[] args) {
       DefaultMailService mailService=new DefaultMailService();
	   LogMailService logMailService=
	   new LogMailService(mailService);
	   logMailService.send("hello cgb1902");
    }
}









