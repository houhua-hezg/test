package com.java.oop;

public class TestClassObject01 {
	public static void main(String[] args)
	throws Exception{
		//1.如何获取类的字节码对象
		//1.1.方式1
		Class<Object> c1=Object.class;
		Class<Object> c2=Object.class;
		System.out.println(c1==c2);
		//1.2.方式2 (这里的?表示泛型通配符)
		Class<?> c3=
		Class.forName("java.lang.Object");
		System.out.println(c2==c3);//true
		//1.3.方式3
		Class<?> c4=new Object().getClass();     
		System.out.println(c3==c4);
		//2.请问类的字节码对象何时创建?
		//类加载时创建
		//3.如何理解类加载?(将类读到内存的过程)
	}
}
