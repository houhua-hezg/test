package com.java.cache;
import java.util.LinkedHashMap;
class LruCache01 extends LinkedHashMap<String,Integer>{ 
  private int maxCap;
  public LruCache01(int cap) {
	  super(cap,0.75f, true);
	  this.maxCap=cap;
  }
  /**此方法返回值为true会从容器中删除最老的元素*/
  @Override
  protected boolean removeEldestEntry(java.util.Map.Entry<String, Integer> eldest) {
		return size()>maxCap;
  }
}
public class TestLruCache01 {
	public static void main(String[] args) {
		LruCache01 c=new LruCache01(3);
		c.put("A", 100);//执行put方法时底层会调用removeEldestEntry
		c.put("B", 200);
		c.put("C", 300);
		c.get("A");
		c.put("D", 400);
		System.out.println(c);//CAD
	}
}




