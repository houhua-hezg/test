package com.java.cache;

import java.util.LinkedHashMap;

public class TestLinkedHashMap01 {
	public static void main(String[] args) {
		LinkedHashMap<String,Integer> map=
		//通过链表默认记录存储顺序
		//new LinkedHashMap<String, Integer>();
		//通过链表记录访问顺序
		new LinkedHashMap<String, Integer>(
				3,0.75f,true);
		map.put("A",100);
		map.put("C",300);
		map.put("D",400);
		map.put("B",200);
		map.get("A");
		map.get("C");
		System.out.println(map);
	}
}






