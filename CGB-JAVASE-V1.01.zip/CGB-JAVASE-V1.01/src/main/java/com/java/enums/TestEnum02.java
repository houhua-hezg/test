package com.java.enums;
enum TransactionIsolationLevel{
	//枚举类的实例对象
	READ_COMMITTED,READ_UNCOMMITTED(1);
	private int level;
	TransactionIsolationLevel(){}
	TransactionIsolationLevel(int level){
		this.level=level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public int getLevel() {
		return level;
	}
}
public class TestEnum02 {
	public static void main(String[] args) {
		int level=
		TransactionIsolationLevel
		.READ_COMMITTED.getLevel();
		System.out.println(level);
	}
}
