package com.java.enums;
/**
 * 枚举定义
 * 1)借助enum关键字
 * 2)枚举类中定义一些实例:
 */
enum Gender{//编译以后是一个.class文件
	MALE,FEMALE,NONE;//对象实例
}
class Product{
	/**商品的性别要求*/
	private Gender gender=Gender.NONE;
	public void setGender(Gender gender) {
		this.gender = gender;
	}
}
public class TestEnum01 {
    public static void main(String[] args) {
		Product p=new Product();
		p.setGender(Gender.MALE);
	}
}
