package com.java.enums;

enum Sex{
	MALE("男"),FEMALE("女");
	private String name;
	private Sex(String name) {
		this.name=name;
	}
}
class Member{
	private Sex sex=Sex.MALE;
	public void setSex(Sex sex) {
		this.sex = sex;
	}
}
public class TestEnum03 {
    public static void main(String[] args) {
		String sex="MALE";
		Member m=new Member();
		m.setSex(Enum.valueOf(Sex.class, sex));
	}
}








