package com.test;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.startup.Tomcat;
import org.junit.Test;
public class TestTomat {
	   //模拟内嵌tomcat的启动方式
	   @Test
	   public void testStart() throws Exception{
		   //构建tomcat对象
		   Tomcat t=new Tomcat();
		   //构建connector对象(此对象负责与客户端通讯)
		   Connector con=new Connector("HTTP/1.1");
		   con.setPort(8080);
		   t.getService().addConnector(con);
		   //.....
		   //启动tomcat
		   t.start();
		   //阻塞主线程
		   t.getServer().await();
	   }
}
