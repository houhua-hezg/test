package com.cy.pj.common.vo;

public enum State {
	DISABLE,ENABLE
}
