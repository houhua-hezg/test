package com.db.common.vo;

public enum State {
	DISABLE,ENABLE
}
