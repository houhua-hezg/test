package com.db.common.config;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.db.sys.service")
public class SpringService {

}
